{!! $body !!}

Regards,
{!! $name !!}
{!! $email !!}